﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modless
{
    public partial class Second : Form
    {
        public event EventHandler<string> TextAlarm;
        public Second()
        {
            InitializeComponent();
        }

        protected void OnTextAlarm(String str)
        {
            TextAlarm?.Invoke(this, str);
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            OnTextAlarm(textBox1.Text);
        }
    }
}
