﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modless
{
    public partial class Form1 : Form
    {
        Second s;
        bool b = false;
        public Form1()
        {
            InitializeComponent();
            s = new Second();
            s.TextAlarm += S_TextAlarm;
        }

        private void S_TextAlarm(object sender, string e)
        {
            this.Text = e;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (b == false)
                s.Show();
            else
                s.Hide();
            b = !b;
        }
    }
}
