﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DialogsWindows
{
    public partial class Second : Form
    {
        public Second()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Dashbords "A"
        /// </summary>
        public String TextInTextBox
        {
            get { return textBox1.Text; }
            set { textBox1.Text = value; }
        }

        //private void bOk_Click(object sender, EventArgs e)
        //{
        //    this.DialogResult = DialogResult.OK;
        //    this.Close();
        //}
    }
}
